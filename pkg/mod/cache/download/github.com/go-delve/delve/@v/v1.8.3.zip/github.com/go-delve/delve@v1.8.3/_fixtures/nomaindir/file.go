package nomaindir

func AFunction() {
}
